﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace InchesToCentmeters
{
    class Program
    {
        static void Main(string[] args)
        {
            const double CENTIMETERS = 2.54;
            int inch = 3;
            WriteLine("{0} inch is {1} centimeters", inch, inch * CENTIMETERS);
        }
    }
}
