﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace CarRental
{
    class Program
    {
        static void Main(string[] args)
        {
            //enter values and assign variables
            WriteLine("Enter the number of days: ");
            int days = Convert.ToInt32(ReadLine());
            WriteLine("Enter the number of miles driven: ");
            int Miles = Convert.ToInt32(ReadLine());
            double DistanceFee = Miles * .25;
            double Total = 20 * days + DistanceFee;
            //write back to user
            WriteLine("If you rent a car for {0} days and drive {1} miles, your rental fee is {2}", days, Miles, Total.ToString("C"));
        }
    }
}
