﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace ProjectedRaises
{
    class Program
    {
        static void Main(string[] args)
        {
            const double PROJECTEDRAISE = .04;
            double sal1 = 100000;
            double sal2 = 200000;
            double sal3 = 1;
            WriteLine("Employee 1 will get a {0} raise, Employee 2 will get a {1} raise, and Employee 3 will get a {2} raise", (PROJECTEDRAISE * sal1).ToString("C"), (PROJECTEDRAISE * sal2).ToString("C"), (PROJECTEDRAISE * sal3).ToString("C"));
        }
    }
}
