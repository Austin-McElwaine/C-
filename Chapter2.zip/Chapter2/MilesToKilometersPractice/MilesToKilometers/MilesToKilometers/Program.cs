﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace MilesToKilometers
{
    class Program
    {
        static void Main(string[] args)
        {
            //constant variable
            const double KILOMETERS = 1.609;
            //variable
            int miles = 20;
            //display and calculate
            WriteLine("{0} miles is {1} kilometers", miles, miles * KILOMETERS);
        }
    }
}
