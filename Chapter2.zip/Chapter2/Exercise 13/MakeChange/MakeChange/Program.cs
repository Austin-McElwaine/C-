﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace MakeChange
{
    class Program
    {
        static void Main(string[] args)
        {
            //initializes doller amounts
            int twenties, ten, fives, ones, dollar, forten, forfive;
            Write("Enter the amount of money you have $");
            dollar = Convert.ToInt32(ReadLine());
            //math
            twenties = dollar / 20;
            forten = dollar % 20;
            ten = forten / 10;
            forfive = forten % 10;
            fives = forfive / 5;
            ones = forfive % 5;
            //display
            WriteLine("{0} dollars is {1} twenties, {2} tens, {3} fives, and {4} ones", dollar, twenties, ten, fives, ones);

        }
    }
}
