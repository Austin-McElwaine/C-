﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace Tests
{
    class Program
    {
        static void Main(string[] args)
        {
            //enter values and assign variables
            WriteLine("Enter score for test1: ");
            double test1 = Convert.ToDouble(ReadLine());
            WriteLine("Enter score for test2: ");
            double test2 = Convert.ToDouble(ReadLine());
            WriteLine("Enter score for test3: ");
            double test3 = Convert.ToDouble(ReadLine());
            WriteLine("Enter score for test4: ");
            double test4 = Convert.ToDouble(ReadLine());
            WriteLine("Enter score for test5: ");
            double test5 = Convert.ToDouble(ReadLine());
            double average = (test1 + test2 + test3 + test4 + test5) / 5;
            average = Math.Round(average, 2);
            //write back to user
            WriteLine("{0}% is the average for the five test scores.", average);
        }
    }
}
