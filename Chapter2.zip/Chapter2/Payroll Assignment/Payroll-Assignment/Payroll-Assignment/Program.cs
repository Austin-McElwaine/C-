﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace Payroll_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            String Name;
            //enter values and assign variables
            WriteLine("Enter Employee Name: ");
            Name = (ReadLine());
            WriteLine("Enter the employee's hourly pay rate: ");
            double HourlyPay;
            HourlyPay = Convert.ToDouble(ReadLine());
            int hours;
            WriteLine("Enter number of hours worked: ");
            hours = Convert.ToInt32(ReadLine());
            double GrossPay = HourlyPay * hours;
            double FWT = .15 * GrossPay;
            double SWT = .05 * GrossPay;
            double NetPay = GrossPay - FWT - SWT;
            //write back to user
            WriteLine("{0} worked {1} hours at a pay rate of {2}.", Name, hours, HourlyPay.ToString("C"));
            WriteLine("Grosspay was {0}", GrossPay.ToString("C"));
            WriteLine("{0} was withheld for federal taxes", FWT.ToString("C"));
            WriteLine("{0} was withheld for state taxes", SWT.ToString("C"));
            WriteLine("Net pay was {0}", NetPay.ToString("C"));
        }
    }
}
