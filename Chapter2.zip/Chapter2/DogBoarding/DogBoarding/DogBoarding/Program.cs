﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace DogBoarding
{
    class Program
    {
        static void Main(string[] args)
        {
            //enter values and assign variables
            WriteLine("Enter the days stayed: ");
            int days = Convert.ToInt32(ReadLine());
            WriteLine("Enter the weight of the dog: ");
            double pounds = Convert.ToDouble(ReadLine());
            //Math
            double cost = (pounds * .85) * days;
            //write back to user
            WriteLine("If I have a {0} pound dog and it is boarded {1} days my total boarding cost should be {2}", pounds, days, cost.ToString("C"));
        }
    }
}
