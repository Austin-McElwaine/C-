﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace bill
{
    class Program
    {
        static void Main(string[] args)
        {
            //enter values and assign variables
            WriteLine("Enter the meal charge: ");
            double Meal = Convert.ToDouble(ReadLine());
            //Math
            double Tax = Meal * .0675;
            double fTip = Meal + Tax;
            double Tip = fTip * .20;
            double Total = Meal + Tax + Tip;
            //write back to user
            WriteLine("Meal cost: {0}", Meal.ToString("C"));
            WriteLine("Tax: {0}", Tax.ToString("C"));
            WriteLine("Tip: {0}", Tip.ToString("C"));
            WriteLine("Total: {0}", Total.ToString("C"));
        }
    }
}
