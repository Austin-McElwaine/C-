﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace ProjectedRaisesInteractive
{
    class Program
    {
        static void Main(string[] args)
        {
            const double PROJECTEDRAISE = .04;
            double sal1, sal2, sal3;
            Write("Enter your salary Employee 1:");
            sal1 = Convert.ToDouble(ReadLine());
            Write("Enter your salary Employee 2:");
            sal2 = Convert.ToDouble(ReadLine());
            Write("Enter your salary Employee 3:");
            sal3 = Convert.ToDouble(ReadLine());
            WriteLine("Employee 1 will get a {0} raise, Employee 2 will get a {1} raise, and Employee 3 will get a {2} raise", (PROJECTEDRAISE * sal1).ToString("C"), (PROJECTEDRAISE * sal2).ToString("C"), (PROJECTEDRAISE * sal3).ToString("C"));
        }
    }
}
