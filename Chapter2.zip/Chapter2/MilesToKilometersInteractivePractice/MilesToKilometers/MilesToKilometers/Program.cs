﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace MilesToKilometers
{
    class Program
    {
        static void Main(string[] args)
        {
            //constant variable
            const double KILOMETERS = 1.609;
            //variable
            double miles;
            //user imput
            Write("Enter the number of miles:");
            //read and convert to a double
            miles = Convert.ToDouble(ReadLine());
            //display
            WriteLine("{0} miles is {1} kilometers", miles, miles * KILOMETERS);
        }
    }
}
