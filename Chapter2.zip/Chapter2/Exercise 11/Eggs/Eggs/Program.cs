﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace Eggs
{
    class Program
    {
        static void Main(string[] args)
        {
            int chick1 = 5, chick2 = 2, chick3 = 6, chick4 = 7;
            int EggTotal = chick1 + chick2 + chick3 + chick4;
            int EggRemainder = EggTotal % 12;
            int Dozens = EggTotal / 12;
            WriteLine("There are {0} dozen(s) and {1} eggs", Dozens, EggRemainder);
        }
    }
}
