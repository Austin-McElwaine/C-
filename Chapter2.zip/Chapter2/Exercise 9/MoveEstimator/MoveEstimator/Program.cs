﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace MoveEstimator
{
    class Program
    {
        static void Main(string[] args)
        {
            //constant variables
            const int BASE = 200, HOURLY = 150, RATE_PER_MILE = 2;
            //variables
            double miles, hours, total;
            //user input
            Write("Enter the number of hours for a job:");
            hours = Convert.ToDouble(ReadLine());
            Write("Enter the number of miles in move");
            miles = Convert.ToDouble(ReadLine());
            //calculation
            total = BASE + HOURLY * hours + RATE_PER_MILE * miles;
            //display
            WriteLine("For a moving taking {0} hours and going {1} miles, the total moving fee is {2}", hours, miles, total.ToString("C"));

        }
    }
}
