﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace InterestCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            //Enter values and assign to variables
            const int months = 12;
            WriteLine("Enter the amount you would like invested");
            int amount = Convert.ToInt32(ReadLine());
            WriteLine("Enter the annual interest rate");
            double interest = Convert.ToDouble(ReadLine());
            double ainterest = interest / 100;
            double sinterest = amount * ainterest / months;
            WriteLine("With an investment of {0} and annual interest rate of {1}%, the simple interest is {2}.", amount.ToString("C"), interest, sinterest.ToString("C"));
        }
    }
}
