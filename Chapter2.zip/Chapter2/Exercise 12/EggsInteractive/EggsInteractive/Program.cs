﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace EggsInteractive
{
    class Program
    {
        static void Main(string[] args)
        {
            //chickens
            int chick1, chick2, chick3, chick4;
            //chicken laid numbers
            Write("Enter the number of eggs the chicken laid:");
            chick1 = Convert.ToInt32(ReadLine());
            Write("Enter the number of eggs the chicken laid:");
            chick2 = Convert.ToInt32(ReadLine());
            Write("Enter the number of eggs the chicken laid:");
            chick3 = Convert.ToInt32(ReadLine());
            Write("Enter the number of eggs the chicken laid:");
            chick4 = Convert.ToInt32(ReadLine());
            int EggTotal = chick1 + chick2 + chick3 + chick4;
            int EggRemainder = EggTotal % 12;
            int Dozens = EggTotal / 12;
            WriteLine("There are {0} dozen(s) and {1} eggs", Dozens, EggRemainder);
        }
    }
}
