﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace Final_Project
{
    class Program
    {
        static void Main(string[] args)
        {
            //motto
            WriteLine("********************************");
            WriteLine("*The stars shine at State Tech.*");
            WriteLine("********************************");
            //variables
            int lycontestants, tycontestants, tyrevenue, lyrevenue;
            //prompt user for contestants
            Write("Contestants last year: ");
            lycontestants = Convert.ToInt32(ReadLine());
            while (lycontestants < 1 || lycontestants > 30)
            {
                WriteLine("Please enter a valid input");
                Write("Contestants last year: ");
                lycontestants = Convert.ToInt32(ReadLine());
            }
            Write("Contestants this year: ");
            tycontestants = Convert.ToInt32(ReadLine());
            while (tycontestants < 1 || tycontestants > 30)
            {
                WriteLine("Please enter a valid input");
                Write("Contestants this year: ");
                tycontestants = Convert.ToInt32(ReadLine());
            }
            //define revenue and display
            lyrevenue = lycontestants * 25;
            tyrevenue = tycontestants * 25;
            WriteLine("Last year's revenue was {0} ", lyrevenue.ToString("C"));
            WriteLine("This year's revenue is {0}", tyrevenue.ToString("C"));
            //compare contestants
            if(tycontestants > lycontestants * 2)
            {
                WriteLine("The competition is more than twice as big this year!");
            }
            else if (tycontestants > lycontestants)
            {
                WriteLine("The competition is bigger than ever!");
            }
            else if (tycontestants < lycontestants)
            {
                WriteLine("It's a tighter race!");
            }
            else if (tycontestants == lycontestants)
            {
                WriteLine("It's going to be a great race this year!");
            }
            //name array
            string[] Names = new string[tycontestants];
            //score array
            int[] Scores = new int[tycontestants];
            int ScoreInput;
            //for loop for input of names and scores
            //fake variable in for loop in order to only add 1 to x if they input a valid score
            int fakenumber = 0;
            for (int x = 0; x < Scores.Length; ++fakenumber)
            {
                Write("Enter the contestant's name: ");
                Names[x] = ReadLine();
                Write("Enter the contestant's score: ");
                ScoreInput = Convert.ToInt32(ReadLine());
                if (ScoreInput <= 10)
                {
                    Scores[x] = ScoreInput;
                    ++x;
                }
                else
                {
                    WriteLine("Please enter a valid score between 1 to 10 inclusive!");
                }
            }
            //Sort the arrays
            Array.Reverse(Scores);
            Array.Reverse(Names);
            //write out scores
            for (int y = 0; y < Scores.Length; ++y)
            {
                WriteLine("The contestant {0} has a score of {1}", Names[y], Scores[y]);
            }
        }
    }
}
