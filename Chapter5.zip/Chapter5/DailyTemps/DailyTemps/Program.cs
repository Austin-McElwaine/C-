﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace DailyTemps
{
    class Program
    {
        static void Main(string[] args)
        {
            //constant variables
            const int LOW = -20, HIGH = 130, QUIT = 999;
            //variables
            double temperature, average, total = 0;
            int count = 0;
            //user input
            Write("Enter a temperature or 999 to quit: ");
            temperature = Convert.ToDouble(ReadLine());
            //loop
            while (temperature != QUIT)
            {
                //check to see if the temp is between -20 and 130
                if(temperature >= LOW && temperature <= HIGH)
                {
                    //calculate the temp
                    total += temperature;
                    ++count;
                }
                else
                {
                    //display invalid temp message
                    WriteLine("The temperature is invalid!");
                }
                //user input
                Write("Enter a temperature or 999 to quit: ");
                temperature = Convert.ToDouble(ReadLine());
            }
            //calc average
            average = total / count;
            //display
            WriteLine("The average of the {0} valid temperatures entered is {1}", count, average.ToString("F2"));
        }
    }
}
