﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace HomeSales
{
    class Program
    {
        static void Main(string[] args)
        {
            //variables
            string initial = "a";
            double HomePrice, dsum = 0, esum = 0, fsum = 0, grandtotal = 0;
            String Winner = "null";
            //loop
            while (initial != "z")
            {
                Write("Is the salesperson D, E, or F: ");
                initial = ReadLine();
                if (initial == "d" || initial == "D")
                {
                    Write("Enter a sale amount: ");
                    HomePrice = Convert.ToDouble(ReadLine());
                    //calculate the sum
                    dsum += HomePrice;
                    grandtotal += HomePrice;
                }
                else if (initial == "e" || initial == "E")
                {
                    Write("Enter a sale amount: ");
                    HomePrice = Convert.ToDouble(ReadLine());
                    //calculate the sum
                    esum += HomePrice;
                    grandtotal += HomePrice;
                }
                else if (initial == "f" || initial == "F")
                {
                    Write("Enter a sale amount: ");
                    HomePrice = Convert.ToDouble(ReadLine());
                    //calculate the sum
                    fsum += HomePrice;
                    grandtotal += HomePrice;
                }
                else if (initial == "z")
                {
                    WriteLine("");
                }
                else
                {
                    WriteLine("Enter a valid option");
                }
            }
            if(dsum > esum && dsum > fsum)
            {
                Winner = "Danielle";
            }
            else if(esum > dsum && esum > fsum)
            {
                Winner = "Edward";
            }
            else if(fsum > dsum && fsum > esum)
            {
                Winner = "Francis";
            }
            //display
            WriteLine("Danielle sold the total of {0}, Edward sold the total of {1}, and Francis sold the total of {2}", dsum.ToString("C"), esum.ToString("C"), fsum.ToString("C"));
            WriteLine("The grand total was {0}", grandtotal.ToString("C"));
            WriteLine("The the sales person with the highest total is {0}", Winner);
        }
    }
}
