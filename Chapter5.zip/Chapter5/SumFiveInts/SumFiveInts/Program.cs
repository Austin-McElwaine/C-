﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace SumFiveInts
{
    class Program
    {
        static void Main(string[] args)
        {
            //variables
            int sum = 0, num;
            //constant
            const int MAX = 5;
            //loop
            for(int x = 0; x < MAX; ++x)
            {
                //user input
                Write("Enter a number: ");
                num = Convert.ToInt32(ReadLine());
                //calculate the sum
                sum += num;
            }
            //display
            WriteLine("The sum of the numbers is {0}", sum);
        }
    }
}
