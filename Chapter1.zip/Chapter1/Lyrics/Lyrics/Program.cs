﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace Lyrics
{
    class Program
    {
        static void Main(string[] args)
        {
            //Piano Man
            WriteLine("It's nine o'clock on a Saturday");
            WriteLine("The regular crowd shuffles in");
            WriteLine("There's an old man sittin' next to me");
            WriteLine("Makin' love to his tonic and gin");
        }
    }
}
