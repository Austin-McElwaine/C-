﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace BigLetter
{
    class Program
    {
        static void Main(string[] args)
        {
            //L
            WriteLine("L");
            WriteLine("L");
            WriteLine("L");
            WriteLine("L");
            WriteLine("L");
            WriteLine("L");
            WriteLine("L");
            WriteLine("L");
            WriteLine("LLLLLLLLLLLLLLL");
        }
    }
}
