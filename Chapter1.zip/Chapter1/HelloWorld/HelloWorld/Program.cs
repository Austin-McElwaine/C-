﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            //this will display Hello, world!
            WriteLine("Hello, world!");

            //this will display the date
            WriteLine("Today is August, 25, 2022");
        }
    }
}
