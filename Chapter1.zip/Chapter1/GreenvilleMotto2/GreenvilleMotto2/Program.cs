﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace GreenvilleMotto2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Greenville motto with asterisks
            WriteLine("*****************************");
            WriteLine("The stars shine in Greenville");
            WriteLine("*****************************");
        }
    }
}
