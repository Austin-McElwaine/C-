﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace StopSign
{
    class Program
    {
        static void Main(string[] args)
        {
            //Stop
            WriteLine("   XXXXXX");
          WriteLine(" X        X");
         WriteLine("X   STOP   X");
          WriteLine(" X        X");
            WriteLine("   XXXXXX");
              WriteLine("      X");
              WriteLine("      X");
              WriteLine("      X");
        }
    }
}
