﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace GreenvilleMotto
{
    class Program
    {
        static void Main(string[] args)
        {
            //Greenville Motto
            WriteLine("The stars shine in Greenville");
        }
    }
}
