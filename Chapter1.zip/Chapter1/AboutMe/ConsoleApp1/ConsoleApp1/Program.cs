﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace AboutMe
{
    class Program
    {
        static void Main(string[] args)
        {
            //all of these will display in the console
            WriteLine("My name is Austin McElwaine");
            WriteLine("I am from Jefferson City, MO");
            WriteLine("I have a dog named Jojo, I was in my highschool's robotics team, The highest I've shot in archery is a 265/300");
        }
    }
}
