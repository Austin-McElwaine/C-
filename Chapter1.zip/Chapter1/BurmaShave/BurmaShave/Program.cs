﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace BurmaShave
{
    class Program
    {
        static void Main(string[] args)
        {
            //Burma Shave Rhyme
            WriteLine("Shave the modern way");
            WriteLine("No brush");
            WriteLine("No lather");
            WriteLine("No rub-in");
            WriteLine("Big tube 35 cents drug stores");
            WriteLine("Burma-Shave");
            WriteLine("Goodbye! shaving brush");
            WriteLine("Half a pound for");
            WriteLine("Half a dollar");
            WriteLine("Very fine for the skin");
            WriteLine("Druggists have it");
            WriteLine("Cheer up face the war is over");
            WriteLine("Burma-Shave");
        }
    }
}
