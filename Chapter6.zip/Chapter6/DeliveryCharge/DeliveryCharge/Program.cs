﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace DeliveryCharge
{
    class Program
    {
        static void Main(string[] args)
        {
            //Weight array
            int[] weight = {1, 3, 5, 10, 15, 20};
            //Price array
            double[] price = {.99, 2.97, 4.95, 9.89, 14.85, 19.79};
            //ask user for inputs
            int iweight;
            int amount;
            bool weightfound = false;
            Write("Enter the weight of the package: ");
            iweight = Convert.ToInt32(ReadLine());
            for(int x = 0; x < weight.Length; ++x)
            {
                if (iweight == weight[x])
                {
                    Write("Enter the shipping amount: ");
                    amount = Convert.ToInt32(ReadLine());
                    weightfound = true;
                    double amountdue = amount * price[x];
                    WriteLine("The amount due is {0}.", amountdue.ToString("C"));
                }
            }
            if(!weightfound)
            {
                WriteLine("Please enter a valid weight");
            }
        }
    }
}
