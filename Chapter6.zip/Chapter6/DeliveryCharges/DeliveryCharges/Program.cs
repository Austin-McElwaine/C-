﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace DeliveryCharges
{
    class Program
    {
        static void Main(string[] args)
        {
            //zip code array
            int[] zipCodes = { 65109, 65051, 65101, 65035, 65058, 65085, 65111, 65123, 65148, 65198 };
            //delivery charges array
            double[] charges = { 3.99, 9.99, 4.25, 8.75, 2.25, 8.99, 12.50, 11.00, 6.75, 4.80 };
            //variable
            int zip;
            bool zipFound = false;
            //user input
            Write("Enter a zip code: ");
            zip = Convert.ToInt32(ReadLine());
            //loop
            for(int x = 0; x < zipCodes.Length; ++x)
            {
                //check to see if the zip the user inputs equals the zip in our array
                if (zip == zipCodes[x])
                {
                    WriteLine("The delivery charge is {0}.", charges[x].ToString("C"));
                    zipFound = true;
                }
            }
            //if the zip does no exist display message
            if(!zipFound)
            {
                WriteLine("The company does not deliver to the requested zip code");
            }
        }
    }
}
