﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace HomeSales
{
    class Program
    {
        static void Main(string[] args)
        {
            string initial = "a";
            string[] SalesPerson = {"Danielle", "Edward", "Francis"};
            string[] Initials = {"D", "d", "E", "e", "F", "f"};
            double[] SalesValues = {0, 0, 0};
            double grandtotal = 0;
            double d = 0, e = 0, f = 0;
            string Winner = "null";
            do
            {
                WriteLine("Is the salesperson D, E, or F: ");
                WriteLine("Enter an invalid option to see results");
                initial = ReadLine();
                if (initial == "d" || initial == "D")
                {
                    Write("Enter a sale amount: ");
                    d = Convert.ToDouble(ReadLine());
                    //calculate the sum
                    SalesValues[0] += d;
                    grandtotal += d;
                }
                else if (initial == "e" || initial == "E")
                {
                    Write("Enter a sale amount: ");
                    e = Convert.ToDouble(ReadLine());
                    //calculate the sum
                    SalesValues[1] += e;
                    grandtotal += e;
                }
                else if (initial == "f" || initial == "F")
                {
                    Write("Enter a sale amount: ");
                    f = Convert.ToDouble(ReadLine());
                    //calculate the sum
                    SalesValues[2] += f;
                    grandtotal += f;
                }
            } while (Initials.Contains(initial));
            if (d > e && d > f)
            {
                Winner = SalesPerson[0];
            }
            else if (e > d && e > f)
            {
                Winner = SalesPerson[1];
            }
            else if (f > d && f > e)
            {
                Winner = SalesPerson[2];
            }
            //display
            WriteLine("Danielle sold the total of {0}, Edward sold the total of {1}, and Francis sold the total of {2}", SalesValues[0].ToString("C"), SalesValues[1].ToString("C"), SalesValues[2].ToString("C"));
            WriteLine("The grand total was {0}", grandtotal.ToString("C"));
            WriteLine("The the sales person with the highest total is {0}", Winner);
        }
    }
}
