﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace ChatAWhile
{
    class Program
    {
        static void Main(string[] args)
        {
            //area code array
            int[] areaCodes = { 262, 414, 608, 715, 815, 920};
            //per-minute charges array
            double[] charges = { 0.07, 0.10, 0.05, 0.16, 0.24, 0.14};
            //variable
            int areaCode;
            int minutes;
            bool areaFound = false;
            //user input
            Write("Enter a area code: ");
            areaCode = Convert.ToInt32(ReadLine());
            Write("Enter how long your call was: ");
            minutes = Convert.ToInt32(ReadLine());
            //loop
            for (int x = 0; x < areaCodes.Length; ++x)
            {
                if (areaCode == areaCodes[x])
                {
                    double Total = charges[x] * minutes;
                    WriteLine("The total cost of the call is {0}.", Total.ToString("C"));
                    areaFound = true;
                }
            }
            //if the areacode does no exist display message
            if (!areaFound)
            {
                WriteLine("This area code does not exist");
            }
        }
    }
}
