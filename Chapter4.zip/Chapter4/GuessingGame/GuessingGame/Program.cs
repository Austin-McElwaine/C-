﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace GuessingGame
{
    class Program
    {
        static void Main(string[] args)
        {
            //random number gen
            Random ranNumberGenerator = new Random();
            int randomNumber;
            randomNumber = ranNumberGenerator.Next(1, 11);
            int userguess;
            //ask user
            Write("Enter your guess 1-10: ");
            userguess = Convert.ToInt32(ReadLine());
            if (userguess == randomNumber)
                WriteLine("Correct!");
            else if (userguess > randomNumber)
                WriteLine("Too High!");
            else if (userguess < randomNumber)
                WriteLine("Too Low!");


        }
    }
}
