﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace PhoneService
{
    class Program
    {
        static void Main(string[] args)
        {
            //variables
            const double PA = 39.99; double PB = 59.99; double AA = .45; double AB = .40; int AM = 450; int BM = 900;
            String userInput; int userMinutes; double userTotal;
            Write("Is your package A, B or C? ");
            userInput = ReadLine();
            Write("How many minutes did you use? ");
            userMinutes = Convert.ToInt32(ReadLine());
            switch(userInput)
            {
                case "A":
                    if(userMinutes > AM)
                    {
                        userTotal = PA + (userMinutes - AM) * AA;
                        WriteLine("Your total is {0}", userTotal.ToString("C"));
                    }
                    else
                    {
                        WriteLine("Your total is $39.99");
                    }
                break;
                case "B":
                    if(userMinutes > BM)
                    {
                        userTotal = PB + (userMinutes - BM) * AB;
                        WriteLine("Your total is {0}", userTotal.ToString("C"));
                    }
                    else
                    {
                        WriteLine("Your total is $59.99");
                    }
                    break;
                case "C":
                            WriteLine("your total is $69.99");
                            break;
                default:
                            WriteLine("Enter a valid option");
                            break;
            }
        }
    }
}
