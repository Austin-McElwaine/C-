﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace Admission
{
    class Program
    {
        static void Main(string[] args)
        {
            //constant variables
            const double GPA = 3.0;
            const int TESTSCORE1 = 60, TESTSCORE2 = 80;
            //variables
            double userGPA, userTestScore;
            //user input
            Write("Enter your grade point average: ");
            userGPA = Convert.ToDouble(ReadLine());
            Write("Enter your test score: ");
            userTestScore = Convert.ToDouble(ReadLine());
            //check to see if GPA is 3.0 or higher and test score is at least 60
            if (userGPA >= GPA && userTestScore >= TESTSCORE1)
                WriteLine("Accept");
            //check to see if GPA is less than 3.0 and test score is at least 80
            else if (userGPA < GPA && userTestScore >= TESTSCORE2)
                WriteLine("Accept");
            else
                WriteLine("Reject");
        }
    }
}
