﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace Commission
{
    class Program
    {
        static void Main(string[] args)
        {
            //variables
            double sales;
            double commission = .05;
            double payout;
            //ask user for input
            Write("What was the sales amount for the month: ");
            sales = Convert.ToDouble(ReadLine());
            //if elses
            if (sales <= 14999 && sales >= 10000)
            {
                commission = .10;
            }
            else if (sales <= 17999 && sales >= 15000)
            {
                commission = .12;
            }
            else if (sales <= 21999 && sales >= 18000)
            {
                commission = .15;
            }
            else if (sales >= 22000)
            {
                commission = .16;
            }
            //display
            payout = sales * commission;
            WriteLine("Your commission for the month is {0}", payout.ToString("C"));
        }
    }
}
