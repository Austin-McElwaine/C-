﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace RockPaperScissors
{
    class Program
    {
        static void Main(string[] args)
        {
            //rng
            Random ranNumberGenerator = new Random();
            int randomNumber;
            randomNumber = ranNumberGenerator.Next(1, 4);
            //variable
            String playerInput;
            //ask user
            Write("Would you like to use Rock (R) Paper (P) or Scissor(S) ");
            playerInput = ReadLine();
            if (playerInput == "R" || playerInput == "P" || playerInput == "S")
            {
                switch (randomNumber)
                {
                    case 1:
                        if (playerInput == "P")
                        {
                            WriteLine("You win!");
                        }
                        else
                            WriteLine("You lose");
                        break;
                    case 2:
                        if (playerInput == "S")
                        {
                            WriteLine("You win!");
                        }
                        else
                            WriteLine("You lose");
                        break;
                    case 3:
                        if (playerInput == "R")
                        {
                            WriteLine("You win!");
                        }
                        else
                            WriteLine("You lose");
                        break;

                }
            }
            else
                WriteLine("Enter a valid option");
        }
    }
}
