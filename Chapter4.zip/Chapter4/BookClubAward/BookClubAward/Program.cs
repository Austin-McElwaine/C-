﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace BookClubAward
{
    class Program
    {
        static void Main(string[] args)
        {
            //variable
            int books;
            Write("Enter the amount of books purchased this month: ");
            books = Convert.ToInt32(ReadLine());
            if (books >= 0)
            {
                switch (books)
                {
                    case 0:
                        WriteLine("You earned 0 points this month");
                        break;
                    case 1:
                        WriteLine("You earned 5 points this month");
                        break;
                    case 2:
                        WriteLine("You earned 15 points this month");
                        break;
                    case 3:
                        WriteLine("You earned 30 points this month");
                        break;
                    default:
                        WriteLine("You earned 60 points this month");
                        break;

                }
            }
            else
                WriteLine("Enter a positive number");
        }
    }
}
