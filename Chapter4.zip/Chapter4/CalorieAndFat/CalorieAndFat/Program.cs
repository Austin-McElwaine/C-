﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace CalorieAndFat
{
    class Program
    {
        static void Main(string[] args)
        {
            double calories; double fatgrams; 
            Write("Enter the number of calories: ");
            calories = Convert.ToDouble(ReadLine());
            Write("Enter the number of fat grams: ");
            fatgrams = Convert.ToDouble(ReadLine());
            double CFF = fatgrams * 9;
            double POF = CFF / calories;
            WriteLine("The total percentage of calories is {0}", POF.ToString("P0"));
            if(POF < .30)
                WriteLine("The food is high in fat");
            else
                WriteLine("The food is low in fat");

        }
    }
}
