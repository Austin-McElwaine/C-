﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace CheckCredit
{
    class Program
    {
        static void Main(string[] args)
        {
            //variables
            const Double CLimit = 8000;
            Double usercredit;
            //ask user
            WriteLine("Enter your credit");
            usercredit = Convert.ToInt32(ReadLine());
            //if else
            if (CLimit >= usercredit)
                WriteLine("Approved");
            else
                WriteLine("Error");
        }
    }
}
