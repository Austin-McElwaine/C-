﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace Twitter
{
    class Program
    {
        static void Main(string[] args)
        {
            //constant variable
            const int MAX = 140;
            //variable
            string message;
            //user input
            Write("Enter a message: ");
            message = ReadLine();
            //if statement
            if (message.Length <= MAX)
                WriteLine("Message accepted!");
            else
                WriteLine("Message is too long.");
        }
    }
}
