﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentalInteractive
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Calc_Click(object sender, EventArgs e)
        {
            // variables
            int Days, Miles;
            Double DistanceFee, Total;
            //convert user input
            Days = Convert.ToInt32(txtnum1.Text);
            Miles = Convert.ToInt32(txtnum2.Text);
            //Math
            DistanceFee = Miles * .25;
            Total = 20 * Days + DistanceFee;
            //write back to user
            lblsum.Visible = true;
            lblsum.Text = String.Format("Your rental fee will be {0}", Total.ToString("C"));
        }
    }
}
