﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Together
{
    public partial class SumNumForm : Form
    {
        public SumNumForm()
        {
            InitializeComponent();
        }

        private void btnsum_Click(object sender, EventArgs e)
        {
            //variables
            int num1, num2, sum;
            //convert user input
            num1 = Convert.ToInt32(txtnum1.Text);
            num2 = Convert.ToInt32(txtnum2.Text);
            //calc
            sum = num1 + num2;
            //set visibility of sum to true
            lblsum.Visible = true;
            //display
            lblsum.Text = "The sum is " + sum;
            //if wanting to display with currency:
            // lblsum.Text = String.Format("The sum in currency is {0}", sum.ToString("C"));
        }
    }
}
