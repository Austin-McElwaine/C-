﻿namespace TestsInteractiveGUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.test1b = new System.Windows.Forms.TextBox();
            this.test2b = new System.Windows.Forms.TextBox();
            this.test3b = new System.Windows.Forms.TextBox();
            this.test4b = new System.Windows.Forms.TextBox();
            this.test5b = new System.Windows.Forms.TextBox();
            this.averageb = new System.Windows.Forms.Button();
            this.lblsum = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // test1b
            // 
            this.test1b.Location = new System.Drawing.Point(12, 22);
            this.test1b.Name = "test1b";
            this.test1b.Size = new System.Drawing.Size(91, 20);
            this.test1b.TabIndex = 0;
            // 
            // test2b
            // 
            this.test2b.Location = new System.Drawing.Point(121, 22);
            this.test2b.Name = "test2b";
            this.test2b.Size = new System.Drawing.Size(95, 20);
            this.test2b.TabIndex = 1;
            // 
            // test3b
            // 
            this.test3b.Location = new System.Drawing.Point(232, 22);
            this.test3b.Name = "test3b";
            this.test3b.Size = new System.Drawing.Size(100, 20);
            this.test3b.TabIndex = 2;
            // 
            // test4b
            // 
            this.test4b.Location = new System.Drawing.Point(350, 22);
            this.test4b.Name = "test4b";
            this.test4b.Size = new System.Drawing.Size(105, 20);
            this.test4b.TabIndex = 3;
            // 
            // test5b
            // 
            this.test5b.Location = new System.Drawing.Point(472, 22);
            this.test5b.Name = "test5b";
            this.test5b.Size = new System.Drawing.Size(95, 20);
            this.test5b.TabIndex = 4;
            // 
            // averageb
            // 
            this.averageb.Location = new System.Drawing.Point(232, 76);
            this.averageb.Name = "averageb";
            this.averageb.Size = new System.Drawing.Size(100, 22);
            this.averageb.TabIndex = 5;
            this.averageb.Text = "Click to average";
            this.averageb.UseVisualStyleBackColor = true;
            this.averageb.Click += new System.EventHandler(this.averageb_Click);
            // 
            // lblsum
            // 
            this.lblsum.AutoSize = true;
            this.lblsum.Location = new System.Drawing.Point(263, 120);
            this.lblsum.Name = "lblsum";
            this.lblsum.Size = new System.Drawing.Size(35, 13);
            this.lblsum.TabIndex = 6;
            this.lblsum.Text = "label1";
            this.lblsum.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(585, 162);
            this.Controls.Add(this.lblsum);
            this.Controls.Add(this.averageb);
            this.Controls.Add(this.test5b);
            this.Controls.Add(this.test4b);
            this.Controls.Add(this.test3b);
            this.Controls.Add(this.test2b);
            this.Controls.Add(this.test1b);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox test1b;
        private System.Windows.Forms.TextBox test2b;
        private System.Windows.Forms.TextBox test3b;
        private System.Windows.Forms.TextBox test4b;
        private System.Windows.Forms.TextBox test5b;
        private System.Windows.Forms.Button averageb;
        private System.Windows.Forms.Label lblsum;
    }
}

