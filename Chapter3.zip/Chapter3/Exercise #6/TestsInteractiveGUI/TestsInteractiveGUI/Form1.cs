﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestsInteractiveGUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void averageb_Click(object sender, EventArgs e)
        {
            //variables
            double test1, test2, test3, test4, test5, average;
            //convert user input
            test1 = Convert.ToDouble(test1b.Text);
            test2 = Convert.ToDouble(test2b.Text);
            test3 = Convert.ToDouble(test3b.Text);
            test4 = Convert.ToDouble(test4b.Text);
            test5 = Convert.ToDouble(test5b.Text);
            //calc
            average = (test1 + test2 + test3 + test4 + test5) / 5;
            average = Math.Round(average, 2);
            //display
            lblsum.Visible = true;
            lblsum.Text = "The average is " + average;
        }
    }
}
