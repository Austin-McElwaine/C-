﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoveEstimatorGUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //constant variables
            const int BASE = 200, HOURLY = 150, RATE_PER_MILE = 2;
            //variables
            double miles, hours, total;
            //user input
            hours = Convert.ToDouble(textBox1.Text);
            miles = Convert.ToDouble(textBox2.Text);
            //calculation
            total = BASE + HOURLY * hours + RATE_PER_MILE * miles;
            //display
            label3.Visible = true;
            label3.Text = String.Format("For a moving taking {0} hours and going {1} miles, the total moving fee is {2}", hours, miles, total.ToString("C"));
        }
    }
}
