﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjecedRaisesGUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button_Click(object sender, EventArgs e)
        {
            //variables
            const double PROJECTEDRAISE = .04;
            double sal1, sal2, sal3;
            sal1 = Convert.ToDouble(emp1.Text);
            sal2 = Convert.ToDouble(emp2.Text);
            sal3 = Convert.ToDouble(emp3.Text);
            //write back to user
            lblsum.Visible = true;
            lblsum.Text = String.Format("Employee 1 will get a {0} raise, Employee 2 will get a {1} raise, and Employee 3 will get a {2} raise", (PROJECTEDRAISE * sal1).ToString("C"), (PROJECTEDRAISE * sal2).ToString("C"), (PROJECTEDRAISE * sal3).ToString("C"));
        }
    }
}
