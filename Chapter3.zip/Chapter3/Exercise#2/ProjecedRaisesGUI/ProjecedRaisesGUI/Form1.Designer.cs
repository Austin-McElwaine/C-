﻿namespace ProjecedRaisesGUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.emp1 = new System.Windows.Forms.TextBox();
            this.emp2 = new System.Windows.Forms.TextBox();
            this.emp3 = new System.Windows.Forms.TextBox();
            this.emp4 = new System.Windows.Forms.TextBox();
            this.button = new System.Windows.Forms.Button();
            this.lblsum = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // emp1
            // 
            this.emp1.Location = new System.Drawing.Point(12, 23);
            this.emp1.Name = "emp1";
            this.emp1.Size = new System.Drawing.Size(100, 20);
            this.emp1.TabIndex = 0;
            // 
            // emp2
            // 
            this.emp2.Location = new System.Drawing.Point(130, 23);
            this.emp2.Name = "emp2";
            this.emp2.Size = new System.Drawing.Size(100, 20);
            this.emp2.TabIndex = 1;
            // 
            // emp3
            // 
            this.emp3.Location = new System.Drawing.Point(251, 23);
            this.emp3.Name = "emp3";
            this.emp3.Size = new System.Drawing.Size(100, 20);
            this.emp3.TabIndex = 2;
            // 
            // emp4
            // 
            this.emp4.Location = new System.Drawing.Point(375, 23);
            this.emp4.Name = "emp4";
            this.emp4.Size = new System.Drawing.Size(100, 20);
            this.emp4.TabIndex = 3;
            // 
            // button
            // 
            this.button.Location = new System.Drawing.Point(205, 76);
            this.button.Name = "button";
            this.button.Size = new System.Drawing.Size(75, 23);
            this.button.TabIndex = 4;
            this.button.Text = "calc";
            this.button.UseVisualStyleBackColor = true;
            this.button.Click += new System.EventHandler(this.button_Click);
            // 
            // lblsum
            // 
            this.lblsum.AutoSize = true;
            this.lblsum.Location = new System.Drawing.Point(12, 46);
            this.lblsum.Name = "lblsum";
            this.lblsum.Size = new System.Drawing.Size(35, 13);
            this.lblsum.TabIndex = 5;
            this.lblsum.Text = "label6";
            this.lblsum.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(43, 7);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "sal1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(168, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "sal2";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(285, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(26, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "sal3";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(408, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "sal4";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(478, 463);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblsum);
            this.Controls.Add(this.button);
            this.Controls.Add(this.emp4);
            this.Controls.Add(this.emp3);
            this.Controls.Add(this.emp2);
            this.Controls.Add(this.emp1);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox emp1;
        private System.Windows.Forms.TextBox emp2;
        private System.Windows.Forms.TextBox emp3;
        private System.Windows.Forms.TextBox emp4;
        private System.Windows.Forms.Button button;
        private System.Windows.Forms.Label lblsum;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}

